function sendMessage() {
  alert("Message sent successfully!");
  return false; // Prevent form reload
}